import tqdm

for i in tqdm.gui.tqdm_gui(range(100000000)):
    pass
